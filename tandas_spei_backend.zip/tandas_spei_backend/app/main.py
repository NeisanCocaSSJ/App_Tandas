# app/main.py

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import uvicorn

# 1. Importa los routers (grupos de endpoints) que has definido
from .api.endpoints import user, tanda, payment

# 2. Crea la instancia principal de la aplicación FastAPI
app = FastAPI(
    title="TandaSPEI Dinámica API",
    description="Backend para la plataforma de ahorro colectivo, incluyendo SPEI y Reorganización Dinámica.",
    version="1.0.0",
)

# 3. Configuración de CORS (Cross-Origin Resource Sharing)
# Esto es esencial para que tu aplicación Flutter (que se ejecuta en un dominio diferente) 
# pueda hacer peticiones a este backend.
origins = [
    "*",  # En desarrollo se usa "*" (todos). En producción, se usaría la URL específica de tu app.
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],  # Permite todos los métodos HTTP (GET, POST, etc.)
    allow_headers=["*"],
)

# 4. Incluir los routers (Endpoints)
# Agrega los archivos de endpoints al objeto principal de la app
app.include_router(user.router, prefix="/api/v1/users", tags=["Users & Auth"])
app.include_router(tanda.router, prefix="/api/v1/tandas", tags=["Tandas Management"])
app.include_router(payment.router, prefix="/api/v1/payments", tags=["Payment & Conciliation"])
# Nota: La lógica de reorganización se llama internamente, no necesita un router público aquí.

# 5. Endpoint de prueba (Ruta raíz)
@app.get("/")
def read_root():
    return {"message": "TandaSPEI Dinámica API está funcionando. Accede a /docs para ver la documentación."}

# 6. Función para ejecutar la aplicación (opcional, se puede ejecutar con uvicorn directamente)
if __name__ == "__main__":
    # Comando de ejecución: uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
    uvicorn.run(app, host="0.0.0.0", port=8000)
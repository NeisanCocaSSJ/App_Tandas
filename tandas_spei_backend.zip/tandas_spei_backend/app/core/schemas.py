# app/core/schemas.py (COMPLETAMENTE CORREGIDO)

from pydantic import BaseModel
from typing import List, Optional

# --- Esquemas para Autenticación ---

class UserLogin(BaseModel):
    email: str
    password: str

class UserResponse(BaseModel):
    id: str
    name: str
    is_suspended: bool

# --- Esquemas para la gestión de Tandas ---

class TandaCreate(BaseModel):
    name: str
    total_amount: float
    participant_count: int
    frequency: str
    creator_id: str

class TandaResponse(BaseModel):
    id: str
    name: str
    total_amount: float
    participant_count: int
    frequency: str
    participants_ids: List[str]
    current_round: int
    status: str
    is_taxable: bool = False

# --- Esquemas para Pagos ---

class PaymentReferenceRequest(BaseModel):
    tanda_id: str
    user_id: str
    amount: float
    method: str

class PaymentReferenceResponse(BaseModel):
    reference_id: str
    payment_method: str
    clabe_bank: str
    amount: float
    # Este campo fue omitido en una respuesta anterior, pero es esencial
    clabe_bank_account: str

class ReportTransaction(BaseModel):
    description: str
    amount: float
    type: str # Aporte Tanda, Recibo Tanda
    origin: str # SPEI, OXXO
    is_gravable: bool = False
    partner: Optional[str] = None # Persona que paga/recibe (para trazabilidad)
# app/core/business_logic/reorganization.py

from typing import List, Dict, Any
import random
from datetime import datetime, timedelta

# --- MOCK DE SERVICIOS NECESARIOS ---
# En producción, estos serían clases reales que interactúan con la DB o APIs
class MockDB:
    """Simulación de la Base de Datos para el MVP."""
    def get_user_status(self, user_id: str) -> bool:
        # Simula que los usuarios con IDs impares (1, 3, 5...) son "cumplidos"
        return int(user_id.split('-')[-1]) % 2 != 0 

    def update_user_suspension(self, user_id: str, status: bool) -> None:
        print(f"    [DB]: Usuario {user_id} marcado como 'suspendido': {status}")

    def create_new_tanda(self, new_tanda_data: Dict[str, Any]) -> str:
        new_id = f"t-reorg-{random.randint(1000, 9999)}"
        print(f"    [DB]: Nueva Tanda de Confianza creada con ID: {new_id}")
        return new_id

# --- SERVICIO PRINCIPAL DE REORGANIZACIÓN ---

class ReorganizationLogic:
    def __init__(self):
        self.db = MockDB()

    async def activate_reorganization_protocol(self, tanda_data: Dict[str, Any], incumplidor_id: str) -> Dict[str, Any]:
        """
        P3.1, P3.3, P3.4: Ejecuta el protocolo de disolución y reasignación.

        Args:
            tanda_data: Datos de la tanda original (simulando TandaModel).
            incumplidor_id: ID del usuario que incumplió el pago.

        Returns:
            Un diccionario con el resultado del protocolo.
        """
        
        print(f"\n[P3.1] Iniciando Protocolo de Reorganización para Tanda: {tanda_data['id']}")
        
        # 1. Identificar Cumplidores (P3.4)
        cumplidores_ids: List[str] = [
            uid for uid in tanda_data['participants_ids'] if uid != incumplidor_id
        ]
        
        # 2. Gestión del Incumplidor (P3.3)
        self.db.update_user_suspension(incumplidor_id, True)
        
        # 3. Disolver la Tanda Original (P3.3)
        print(f"    Tanda Original {tanda_data['id']} marcada como DISUELTA.")
        
        # 4. Algoritmo de Reasignación Dinámica (P3.4)
        if not cumplidores_ids:
            return {"status": "success", "message": "No hay participantes cumplidos para reasignar."}

        # Generar nueva Tanda de Confianza (P3.4)
        new_tanda = self._generate_confidence_tanda(tanda_data, cumplidores_ids)
        new_tanda_id = self.db.create_new_tanda(new_tanda)
        
        return {
            "status": "success",
            "message": "Protocolo de Reorganización Dinámica completado.",
            "new_tanda_id": new_tanda_id,
            "reassigned_users": cumplidores_ids,
        }

    def _generate_confidence_tanda(self, old_tanda: Dict[str, Any], cumplidores_ids: List[str]) -> Dict[str, Any]:
        """
        Crea la nueva tanda con un calendario recalculado para los cumplidores.
        """
        
        # Recalcular el calendario (lógica simplificada para el MVP)
        remaining_rounds = len(cumplidores_ids)
        
        # Simular un nuevo orden de turnos aleatorio para evitar problemas
        new_turn_order = list(range(1, remaining_rounds + 1))
        random.shuffle(new_turn_order)

        # Simular una nueva fecha de inicio
        new_start_date = (datetime.now() + timedelta(days=2)).isoformat()
        
        return {
            "name": f"Confianza - {old_tanda['name']}",
            "total_amount": old_tanda['total_amount'],
            "participant_count": remaining_rounds,
            "frequency": old_tanda['frequency'],
            "participants_ids": cumplidores_ids,
            "turn_order": new_turn_order,
            "current_round": 1,
            "reorganized_from": old_tanda['id'],
            "start_date": new_start_date
        }
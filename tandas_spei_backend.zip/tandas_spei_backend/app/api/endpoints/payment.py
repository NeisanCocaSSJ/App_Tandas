# app/api/endpoints/payment.py

from fastapi import APIRouter, HTTPException, status
from app.core.schemas import PaymentReferenceRequest, PaymentReferenceResponse
import random
from datetime import datetime

router = APIRouter()

def mock_custody_api_call(request: PaymentReferenceRequest) -> PaymentReferenceResponse:
    """
    Simula la llamada a la entidad custodia (SOFIPO/ITF aliada) para obtener la referencia única.
    Esta función es el punto de integración con el sistema SPEI del banco.
    """

    tanda_suffix = request.tanda_id.split('-')[-1]
    reference_id = f"REF-{tanda_suffix}-{datetime.now().strftime('%H%M%S')}{random.randint(10, 99)}"

    payment_method = request.method.upper()

    if payment_method == 'SPEI':
        clabe_bank_account = f"999180123456789{random.randint(100, 999)}"
        clabe_bank_name = "SOFIPO/ITF ALIADA (SPEI)"
    elif payment_method == 'CORRESPONSAL':
        clabe_bank_account = f"888999{random.randint(1000000, 9999999)}"
        clabe_bank_name = "CORRESPONSAL (OXXO/7-E)"
    else:
        raise HTTPException(status_code=400, detail="Método de pago no soportado.")

    return PaymentReferenceResponse(
        reference_id=reference_id,
        payment_method=payment_method,
        clabe_bank=clabe_bank_name,
        amount=request.amount,
        clabe_bank_account=clabe_bank_account
    )

@router.post("/generate-ref", response_model=PaymentReferenceResponse, status_code=status.HTTP_200_OK)
async def generate_payment_reference(request: PaymentReferenceRequest):
    """Genera la referencia única para una aportación."""
    if request.amount <= 0:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="El monto a pagar debe ser positivo."
        )

    try:
        payment_ref = mock_custody_api_call(request)
        return payment_ref

    except HTTPException as e:
        raise e
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error interno al generar la referencia de pago: {str(e)}"
        )
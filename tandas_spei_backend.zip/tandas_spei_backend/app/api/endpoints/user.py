# app/api/endpoints/user.py

from fastapi import APIRouter, status, HTTPException
from app.core.schemas import UserLogin, UserResponse
from app.core.schemas import UserResponse
from typing import List

router = APIRouter() # <--- La clave que faltaba

@router.post("/login", response_model=UserResponse)
async def login_user(credentials: UserLogin):
    # Mock de Login para el MVP
    if credentials.email == "neisan@test.com" and credentials.password == "1234":
        return UserResponse(
            id="u-001",
            name="Neisan Aspire",
            is_suspended=False
        )
    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Credenciales incorrectas"
    )

@router.get("/{user_id}", response_model=UserResponse)
async def get_user_profile(user_id: str):
    # Mock de Perfil
    if user_id == "u-001":
        return UserResponse(
            id="u-001",
            name="Neisan Aspire",
            is_suspended=False
        )
    raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Usuario no encontrado")

@router.patch("/{user_id}/suspend", response_model=UserResponse)
async def update_user_suspension(user_id: str, is_suspended: bool):
    """
    PATCH /api/v1/users/{user_id}/suspend
    Simula la suspensión o rehabilitación de un usuario (P3.3).
    """
    # 1. Simulación: Buscar el usuario en la DB Mock
    # Nota: Aquí deberías buscar el usuario real en tu base de datos.

    if user_id == "u-incumplidor-002":
        # Simula la actualización del estado de suspensión

        return UserResponse(
            id=user_id,
            name="Juan P. Incumplidor",
            is_suspended=is_suspended, # Devuelve el estado actualizado
        )

    raise HTTPException(status_code=404, detail="Usuario no encontrado")
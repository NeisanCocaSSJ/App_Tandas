# app/api/endpoints/tanda.py

from fastapi import APIRouter, HTTPException, status
# Importamos los esquemas principales que ya tenías
from app.core.schemas import TandaCreate, TandaResponse
from pydantic import BaseModel # Necesario para definir PaymentStatusDetail aquí
from typing import List
import uuid
import random

router = APIRouter()

# --- ESQUEMA DE RESPUESTA PARA EL NUEVO ENDPOINT (P2: Transparencia) ---

# Mock simple para asegurar que FastAPi compile
class PaymentStatusDetail(BaseModel):
    user_id: str
    user_name: str
    status_icon: str
    amount: float
    is_guaranteed: bool = False
    payment_date: str
    payment_method: str

# --- MOCK DE BASE DE DATOS (REEMPLAZAR EN PRODUCCIÓN) ---

# Usamos una lista global en memoria para simular la base de datos de tandas.
mock_tandas_db = [
    TandaResponse(
        id='t-123', name='Ahorro Viaje Familiar', total_amount=10000.0,
        participant_count=10, frequency='Semanal', contribution_amount=1000.0, # Añadido contribution_amount
        participants_ids=['u-001', 'u-002', 'u-carlos', 'u-maria', 'u-juan'],
        current_round=3, status='ACTIVE', is_taxable=False,
    ),
    TandaResponse(
        id='t-124', name='Capital para Emprendimiento', total_amount=20000.0,
        participant_count=5, frequency='Mensual', contribution_amount=4000.0, # Añadido contribution_amount
        participants_ids=['u-001', 'u-006'],
        current_round=1, status='PENDING_PAYMENT', is_taxable=False,
    ),
]

def mock_db_create_tanda(tanda_data: TandaCreate) -> TandaResponse:
    """Simula la lógica de negocio para crear y guardar la tanda en la DB."""

    tanda_id = str(uuid.uuid4())
    participants = [tanda_data.creator_id]

    # Calcular monto de contribución por ronda
    contribution_amount = tanda_data.total_amount / tanda_data.participant_count

    new_tanda = TandaResponse(
        id=tanda_id,
        name=tanda_data.name,
        total_amount=tanda_data.total_amount,
        participant_count=tanda_data.participant_count,
        frequency=tanda_data.frequency,
        contribution_amount=contribution_amount, # Agregado al mock
        participants_ids=participants,
        current_round=1,
        status="OPEN_FOR_INVITE",
        is_taxable=False,
    )

    mock_tandas_db.append(new_tanda)
    return new_tanda

# -------------------------------------------------------------------
# --- ENDPOINTS ---
# -------------------------------------------------------------------

@router.post("/", response_model=TandaResponse, status_code=status.HTTP_201_CREATED)
async def create_new_tanda(tanda: TandaCreate):
    """
    POST /api/v1/tandas/
    Crea una nueva instancia de tanda (Paso 1: Creación).
    """

    if tanda.total_amount <= 0 or tanda.participant_count < 2:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Monto total debe ser positivo y se requieren al menos 2 participantes."
        )

    try:
        new_tanda = mock_db_create_tanda(tanda)
        return new_tanda

    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error al crear la tanda: {str(e)}"
        )

@router.get("/{user_id}", response_model=List[TandaResponse])
async def get_active_tandas(user_id: str):
    """
    GET /api/v1/tandas/{user_id}
    Obtiene la lista de tandas activas o pendientes de un usuario (HomeScreen).
    """
    # Filtra las tandas que incluyen al user_id en la lista de participantes
    user_tandas = [t for t in mock_tandas_db if user_id in t.participants_ids]

    return user_tandas

# --- NUEVO ENDPOINT: REGISTRO DE PAGOS DE LA RONDA ACTUAL (P2) ---

@router.get("/{tanda_id}/payments/current", response_model=List[PaymentStatusDetail])
async def get_current_round_payments(tanda_id: str):
    """
    GET /api/v1/tandas/{tanda_id}/payments/current
    Devuelve el registro de pagos de la ronda actual (Transparencia Total - P2).
    """
    # Mock de datos basado en la Página 17 (Ahorro Viaje Familiar)
    return [
        PaymentStatusDetail(
            user_id="u-carlos",
            user_name="Carlos G",
            status_icon="check", # Pagado
            amount=1000.0, # Monto de contribución (ajustado para t-123)
            payment_date="15/Mayo",
            payment_method="SPEI",
        ),
        PaymentStatusDetail(
            user_id="u-maria",
            user_name="Maria R.",
            status_icon="pending", # Pendiente
            amount=1000.0,
            payment_date="14/Mayo",
            payment_method="OXXO",
        ),
        PaymentStatusDetail(
            user_id="u-juan",
            user_name="Juan P.",
            status_icon="x", # Incumplido
            amount=1000.0,
            payment_date="14/Mayo",
            payment_method="N/A",
            is_guaranteed=True # CLAVE: Simula la cobertura del Fondo de Garantía (P3.2)
        ),
    ]

# --- NUEVO ENDPOINT: HISTORIAL DE TANDAS (P6) ---

@router.get("/{user_id}/history", response_model=List[TandaResponse])
async def get_tanda_history(user_id: str):
    """
    GET /api/v1/tandas/{user_id}/history
    Obtiene todas las tandas que el usuario ha completado (Historial - P6).
    """
    # Mock de datos: Simulación de tandas completadas para el usuario 'u-001'
    if user_id == "u-001":
        return [
            TandaResponse(
                id='t-comp-01', name='Ahorro Vacaciones 2024', total_amount=5000.0,
                participant_count=5, frequency='Semanal', contribution_amount=1000.0,
                participants_ids=['u-001'],
                current_round=5, status='COMPLETED', is_taxable=False,
            ),
            TandaResponse(
                id='t-comp-02', name='Fondo de Emergencia', total_amount=3000.0,
                participant_count=3, frequency='Mensual', contribution_amount=1000.0,
                participants_ids=['u-001'],
                current_round=3, status='COMPLETED', is_taxable=False,
            ),
        ]
    return []